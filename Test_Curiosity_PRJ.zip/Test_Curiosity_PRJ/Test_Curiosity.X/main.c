#include "mcc_generated_files/system/system.h"
#include "I2C_LCD.h"
#include <stdio.h> // Ajout de cette biblioth�que pour utiliser sprintf

/*
    Main application
*/

void TMR0_Custom_ISR(void);
void UART_Custom_ISR(uint8_t Rx_Code);
double GetDistance(void);

// D�placement
void forward(void);
void backward(void);
void left(void);
void right(void);
void stop(void);

// Donn�es
double GetTemperature(void);
double GetDistance(void);

double distance;
double distance_right;
double distance_left;
double temperature;

int main(void)
{
    SYSTEM_Initialize();

    // Disable I2C Interrupts
    PIE1bits.SSP1IE = 0; 
    PIE2bits.BCL1IE = 0; 
    
    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    I2C_Master_Init();
    LCD_Init(0x4E); // Initialize LCD module with I2C address = 0x4E
    
    Backlight();
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("  EFREI Paris ");
    LCD_Set_Cursor(2, 1);
    LCD_Write_String("Embedded Systems");
        
    LCD_Clear();
    LCD_Set_Cursor(1,1);
    LCD_Write_String(" Projet ");
    LCD_Set_Cursor(2,1);
    LCD_Write_String(" Groupe 4 ");
    // Set everything to 0 (Stop)
    LATBbits.LATB6 = 0;
    LATBbits.LATB5 = 0;
    LATAbits.LATA5 = 0;
    LATAbits.LATA4 = 0;
    
    while(1)
    {    
        INTCONbits.TMR0IE = 0; // Disable TMR0 interrupt
        
        
        
        
        
        distance = GetDistance();
        /*if (distance >= 30){
            forward();
        }else if (distance <30 && distance >10){
            stop();
            left();
            __delay_ms(1000);
            distance_left = GetDistance();
            right();
            __delay_ms(2000);
            distance_right = GetDistance();
            left();
            __delay_ms(1000);
            if (distance_right > distance_left){
                right();
                __delay_ms(1000);
            }else{
                left();
                __delay_ms(1000);
            }
        }else {
            backward();
            stop();
        }*/
        
        /*
        LCD_Clear();
        LCD_Set_Cursor(1, 1);
        LCD_Write_String("  ** Projet **");
        LCD_Set_Cursor(2, 1);
        LCD_Write_String("Solution Factory");
        __delay_ms(500);
        */
    }   
}

void UART_Custom_ISR(uint8_t Rx_Code)
{
    char buffer[16];
    
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    Backlight();
    LCD_Write_String(" UART ..");
    LCD_Set_Cursor(2, 1);
    LCD_Write_String(" .. Interrupt");
    __delay_ms(350);
    
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    sprintf(buffer, "Sent code: %hhx", Rx_Code);
    LCD_Write_String(buffer);  // Display the code on the LCD
    __delay_ms(350);
}

void TMR0_Custom_ISR(void)
{
    char buffer[16];
    
    LCD_Clear();
    LCD_Set_Cursor(1, 1);
    Backlight();
    LCD_Write_String(" TMR0 ..");
    LCD_Set_Cursor(2, 1);
    LCD_Write_String(" .. Interrupt");
    __delay_ms(1000);
    
    TMR1H = 0x00;
    TMR1L = 0x00;
    // Generate a 10 microseconds pulse on Trig output
    Trig_SetHigh();
    __delay_us(10);
    Trig_SetLow();
    // Wait for Echo pin rising edge
    while(Echo_PORT == LOW);
    // Start measuring Echo pulse width in seconds
    TMR1_Start();
    // Wait for Echo pin falling edge
    while(Echo_PORT == HIGH);
    // Stop the timer 
    TMR1_Stop();
    // Estimate the distance in CM
    distance = ((double)((TMR1H<<8) + TMR1L))/58.82;
    if(distance >= 2 && distance <= 400) // Check whether the result is valid or not
    { 
        LCD_Clear();
        LCD_Set_Cursor(1, 1);
        sprintf(buffer, "Dist.: %.2f cm", distance);
        LCD_Write_String(buffer);  // Display the distance on the LCD
    }
    else 
    {
        LCD_Clear();
        LCD_Set_Cursor(1, 1);
        char result[20] = "out of range";
        LCD_Write_String(result);
    }

    temperature = ((double)(ADC_GetConversion(0) & 0x3FF) * 3.3/1023)*100;
    ADCON0bits.ADON = 0;

    LCD_Set_Cursor(2, 1); 
    sprintf(buffer, "Temp.: %.2f C", temperature);
    LCD_Write_String(buffer);  // Display the temperature on the LCD
    
    __delay_ms(1000);
}

// FONCTIONS DEPLACEMENT
void forward(void)
{  
    // Set RB5 to 1 and RB6 to 0 (Forward)
    LATBbits.LATB6 = 0;
    LATBbits.LATB5 = 1; 
    // Set RA4 to 1 and RA5 to 0 (Forward)
    LATAbits.LATA4=1;
    LATAbits.LATA5=0;
    LCD_Clear();
    CCP1_LoadDutyValue(1000);
    CCP2_LoadDutyValue(1000);
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("FORWARD");
}

void backward(void)
{
    // Set RB5 to 0 and RB6 to 1 (Backward)
    LATBbits.LATB6 = 1;
    LATBbits.LATB5 = 0; 
    // Set RA4 to 0 and RA5 to 1 (Backward)
    LATAbits.LATA4=0;
    LATAbits.LATA5=1;
    LCD_Clear();
    CCP1_LoadDutyValue(1000);
    CCP2_LoadDutyValue(1000);
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("BACKWARD");
}

void left(void)
{
    // Set RB5 to 0 and RB6 to 1 (Backward)
    LATBbits.LATB6 = 0;
    LATBbits.LATB5 = 1; 
    // Set RA4 to 0 and RA5 to 1 (Backward)
    LATAbits.LATA4=0;
    LATAbits.LATA5=1;
    LCD_Clear();
    CCP1_LoadDutyValue(1000);
    CCP2_LoadDutyValue(1000);
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("LEFT");
}

void right(void)
{
    // Set RB5 to 0 and RB6 to 1 (Backward)
    LATBbits.LATB6 = 1;
    LATBbits.LATB5 = 0; 
    // Set RA4 to 0 et RA5 � 1 (Backward)
    LATAbits.LATA4=1;
    LATAbits.LATA5=0;
    LCD_Clear();
    CCP1_LoadDutyValue(1000);
    CCP2_LoadDutyValue(1000);
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("RIGHT");
}

void stop(void)
{
    // Set everything to 0 (Stop)
    LATBbits.LATB6 = 0;
    LATBbits.LATB5 = 0; 
    LATAbits.LATA4= 0;
    LATAbits.LATA5= 0;
    LCD_Clear();
    CCP1_LoadDutyValue(0);
    CCP2_LoadDutyValue(0);
    LCD_Set_Cursor(1, 1);
    LCD_Write_String("STOP");   
}

// FONCTIONS DONNEES
double GetTemperature(void)
{
    temperature = ((double)(ADC_GetConversion(0) & 0x3FF) * 3.3/1023)*100;
    ADCON0bits.ADON = 0;
    
    return temperature;
}

double GetDistance(void)
{
    TMR1H = 0x00;
    TMR1L = 0x00;
    // Generate a 10 microseconds pulse on Trig output
    Trig_SetHigh();
    __delay_us(10);
    Trig_SetLow();
    // Wait for Echo pin rising edge
    while(Echo_PORT == LOW);
    // Start measuring Echo pulse width in seconds
    TMR1_Start();
    // Wait for Echo pin falling edge
    while(Echo_PORT == HIGH);
    // Stop the timer 
    TMR1_Stop();
    // Estimate the distance in CM
    distance = ((double)((TMR1H << 8) + TMR1L))/58.82;
    return distance;
}
